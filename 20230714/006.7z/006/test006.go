package main

import (
	"database/sql"
	"fmt"
	"io"
	"os"

	_ "github.com/sijms/go-ora/v2"
)

func dieOnError(msg string, err error) {
	if err != nil {
		fmt.Println(msg, err)
		os.Exit(1)
	}
}

func main() {
	fmt.Printf("Hello oracle\n")

	//conn, err := sql.Open("oracle", "oracle://user:pass@server/service_name")
	conn, err := sql.Open("oracle", "oracle://ncbuser_u3:ncb_user_u3@DBDEV02")

	dieOnError("Can't create connection:", err)

	// check for error
	defer conn.Close()

	err = conn.Ping()
	dieOnError("Can't ping connection:", err)

	fmt.Println("\nSuccessfully connected.")

	stmt, err := conn.Prepare("SELECT TRACKING_CODE FROM RISK_SCORE_BATCH_DATA t")
	dieOnError("Can't prepare query:", err)
	// check for error
	defer stmt.Close()

	// suppose we have 2 params one time.Time and other is double
	rows, err := stmt.Query()
	dieOnError("Can't create query:", err)
	defer rows.Close()

	for rows.Next() {
		var s string
		err := rows.Scan(&s)
		if err != nil {
			break
		}
		fmt.Println(s)
	}
	if rows.Err() != nil && rows.Err() != io.EOF {
		dieOnError("Can't fetch row:", rows.Err())
	}
}
